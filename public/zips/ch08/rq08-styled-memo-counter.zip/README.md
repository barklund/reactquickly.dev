## `rq08-styled-memo-counter` from React Quickly, 2nd ed

This folder contains the example `rq08-styled-memo-counter`, which is featured in Chapter 8 of [React Quickly, 2nd ed](https://reactquickly.dev).
