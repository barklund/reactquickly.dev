import { createContext } from "use-context-selector";

const DataContext = createContext({});

export default DataContext;
