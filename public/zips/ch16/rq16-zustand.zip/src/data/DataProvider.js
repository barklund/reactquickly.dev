import "./useData";

function DataProvider({ children }) {
  return children;
}

export default DataProvider;
