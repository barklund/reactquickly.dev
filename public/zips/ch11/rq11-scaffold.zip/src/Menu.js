function Menu() {
  return <nav></nav>;
}

export default Menu;
