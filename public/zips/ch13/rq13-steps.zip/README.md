## `rq13-steps` from React Quickly, 2nd ed

This folder contains the example `rq13-steps`, which is featured in Chapter 13 of [React Quickly, 2nd ed](https://reactquickly.dev).
