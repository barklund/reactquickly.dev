import { createContext } from "react";

const TaskContext = createContext({ state: {}, actions: {} });

export default TaskContext;
