const initialState = [
  { id: 1, title: "Make task manager" },
  { id: 2, title: "Now add some more tasks" },
];

export default initialState;
