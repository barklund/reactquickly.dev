import { createContext } from "react";

const StepContext = createContext({ state: {}, actions: {} });

export default StepContext;
