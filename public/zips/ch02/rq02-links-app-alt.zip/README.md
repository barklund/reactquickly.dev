## `rq02-links-app-alt` from React Quickly, 2nd ed

This folder contains the example `rq02-links-app-alt`, which is featured in Chapter 2 of [React Quickly, 2nd ed](https://reactquickly.dev).
