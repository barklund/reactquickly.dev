function useData(selector) {
  return {};
}

export default useData;
