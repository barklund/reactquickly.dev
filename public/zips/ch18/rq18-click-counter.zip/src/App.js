import Counter from "./Counter";

function App() {
  return <Counter start={5} />;
}

export default App;
