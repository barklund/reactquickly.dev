import WhereAmI from "./WhereAmI";

function App() {
  return <WhereAmI />;
}

export default App;
