import { createContext } from "use-context-selector";

const DarkModeContext = createContext({});

export default DarkModeContext;
