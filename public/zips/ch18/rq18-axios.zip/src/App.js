import StarshipList from "./StarshipList";

function App() {
  return <StarshipList />;
}

export default App;
