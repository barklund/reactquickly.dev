## `rq04-menu-function` from React Quickly, 2nd ed

This folder contains the example `rq04-menu-function`, which is featured in Chapter 4 of [React Quickly, 2nd ed](https://reactquickly.dev).
