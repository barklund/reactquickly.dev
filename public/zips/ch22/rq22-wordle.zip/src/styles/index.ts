export { default as StyleProvider } from "./Provider";
export { default as theme } from "./theme";
export { default as GlobalStyles } from "./GlobalStyles";
