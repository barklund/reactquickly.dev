## `rq07-employee-list` from React Quickly, 2nd ed

This folder contains the example `rq07-employee-list`, which is featured in Chapter 7 of [React Quickly, 2nd ed](https://reactquickly.dev).
