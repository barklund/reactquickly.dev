import { createContext } from "react";

const ToastContext = createContext(null);

export default ToastContext;
