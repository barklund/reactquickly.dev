function App() {
  return (
    <main>
      <h1>Check storybook, please</h1>
    </main>
  );
}

export default App;
