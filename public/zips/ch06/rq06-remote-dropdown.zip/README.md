## `rq06-remote-dropdown` from React Quickly, 2nd ed

This folder contains the example `rq06-remote-dropdown`, which is featured in Chapter 6 of [React Quickly, 2nd ed](https://reactquickly.dev).
