import { Component } from "react";
class App extends Component {
  render() {
    return (
      <h1>
        All
        <em>corgis</em>
        are awesome
      </h1>
    );
  }
}
export default App;
