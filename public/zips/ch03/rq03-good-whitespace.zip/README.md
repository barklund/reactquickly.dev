## `rq03-good-whitespace` from React Quickly, 2nd ed

This folder contains the example `rq03-good-whitespace`, which is featured in Chapter 3 of [React Quickly, 2nd ed](https://reactquickly.dev).
