## `rq03-naive-select` from React Quickly, 2nd ed

This folder contains the example `rq03-naive-select`, which is featured in Chapter 3 of [React Quickly, 2nd ed](https://reactquickly.dev).
