## `rq12-scaffold` from React Quickly, 2nd ed

This folder contains the example `rq12-scaffold`, which is featured in Chapter 12 of [React Quickly, 2nd ed](https://reactquickly.dev).
