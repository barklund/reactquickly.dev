import Timer from "./Timer";

function TimerManager() {
  return (
    <div className="timers">
      <Timer />
    </div>
  );
}

export default TimerManager;
