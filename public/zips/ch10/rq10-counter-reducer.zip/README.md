## `rq10-counter-reducer` from React Quickly, 2nd ed

This folder contains the example `rq10-counter-reducer`, which is featured in Chapter 10 of [React Quickly, 2nd ed](https://reactquickly.dev).
