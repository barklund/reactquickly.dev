## `rq10-reducer-load` from React Quickly, 2nd ed

This folder contains the example `rq10-reducer-load`, which is featured in Chapter 10 of [React Quickly, 2nd ed](https://reactquickly.dev).
